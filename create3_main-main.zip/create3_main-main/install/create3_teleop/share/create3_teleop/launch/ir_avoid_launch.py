from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():

    return LaunchDescription([
        Node(
            package='create3_teleop',
            executable='ir_avoider',
            name=f'ir_avoider_node',
            output='screen'
        )
    ])

if __name__ == '__main__':
    generate_launch_description()
