import os
from glob import glob
from setuptools import find_packages, setup

package_name = 'create3_teleop'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        (os.path.join('share', package_name, "launch"),
         glob(os.path.join('launch', '*launch.py'))),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Yongxu Ren',
    maintainer_email='yongxu.ren@fau.de',
    description='Example launch files for teleoperating the iRobot(R) Create(R) 3 Educational Robot.',
    license='BSD-3',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'teleop_twist_keyboard = create3_teleop.teleop_twist_keyboard:main',
            'ir_avoider = create3_teleop.ir_avoider:main',
            'ir_mapper = create3_teleop.ir_mapper:main',
        ],
    },
)
