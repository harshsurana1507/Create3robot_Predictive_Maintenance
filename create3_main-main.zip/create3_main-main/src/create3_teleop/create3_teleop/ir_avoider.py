#!/usr/bin/env python

import rclpy
import random as rd
from rclpy.node import Node
from rclpy.action import ActionClient
#from sensor_msgs.msg import LaserScan, Range
from irobot_create_msgs.msg import IrIntensity, IrIntensityVector, HazardDetectionVector
from irobot_create_msgs.action import RotateAngle
from rclpy.qos import QoSProfile, ReliabilityPolicy, LivelinessPolicy, DurabilityPolicy
from geometry_msgs.msg import Twist

IR_TOPIC = '/robot01/ir_intensity'
HAZARD_TOPIC = '/robot01/hazard_detection'
TWIST_TOPIC =  '/robot01/cmd_vel'
ROTATE_ACTION = '/robot01/rotate_angle'

# IR_TOPIC = '/ir_intensity'
# TWIST_TOPIC = '/cmd_vel'
# ROTATE_ACTION = '/rotate_angle'

# Parameters to configure movement of the robot
LINEAR_VELOCITY = 0.15
ANGULAR_VELOCITY = 0.5
ROTATE_DURATION = 1
# Threshold for obstacles detection through IR sensor
OBSTACLE_THRESHOLD = 150


ir_sensors = {
    "ir_intensity_side_left": 0,
    "ir_intensity_left": 1,
    "ir_intensity_front_left": 2,
    "ir_intensity_front_center_left": 3,
    "ir_intensity_front_center_right": 4,
    "ir_intensity_front_right": 5,
    "ir_intensity_right": 6
}

# v_vector contains the speed in 6 different directions, first three are linear x,y,z; last three are rotate x,y,z
v_vector = {
    "linear_x": 0.0,
    "linear_y": 0.0,
    "linear_z": 0.0,
    "angular_x": 0.0,
    "angular_y": 0.0,
    "angular_z": 0.0,
}

class ObstacleAvoider(Node):
    
    def __init__(self):
        super().__init__('obstacle_avoider')

        self.get_logger().info('Launch Avoider')

        qos_profile = rclpy.qos.QoSProfile(
            depth = 0,  # Set an appropriate depth value
            reliability = rclpy.qos.QoSReliabilityPolicy.BEST_EFFORT,
        )
        
        self.ir_subscription = self.create_subscription(
            IrIntensityVector,
            IR_TOPIC,
            self.ir_scan_callback,
            qos_profile
        )

        self.hazard_subscription = self.create_subscription(
            HazardDetectionVector,
            HAZARD_TOPIC,
            self.hazard_callback,
            qos_profile
        )

        self.publisher = self.create_publisher(Twist, TWIST_TOPIC, qos_profile)
        self.twist_msg = Twist()

        # Initialize action client for rotate_angle action
        self.rotate_client = ActionClient(self, RotateAngle, ROTATE_ACTION)

        self.angular_velocity = ANGULAR_VELOCITY
        self.linear_velocity = LINEAR_VELOCITY
        self.rotate_duration = ROTATE_DURATION
        self.obstacle_threshold = OBSTACLE_THRESHOLD
        self.ir_vector = [0] * 7
    

    def move_forward(self):
        '''
        move forward
        '''
        self.get_logger().info('Moving Forward!')
        v_vector["linear_x"] = self.linear_velocity
        v_vector["angular_z"] = 0.0 

    def turn_clockwise(self):
        '''
        turn clockwise
        '''
        self.get_logger().info('Rotating Clockwise!')
        v_vector["linear_x"] = 0.0
        v_vector["angular_z"] = -self.angular_velocity

    def turn_anticlockwise(self):
        '''
        turn anticlockwise
        '''
        self.get_logger().info('Rotating Anticlockwise!')
        v_vector["linear_x"] = 0.0
        v_vector["angular_z"] = self.angular_velocity
    
    def rotate_robot(self, angle):
        """
        Create goal message for the rotate_angle action
        """
        self.get_logger().info('Turning Around!')
        goal_msg = RotateAngle.Goal()
        goal_msg.angle = angle
        goal_msg.max_rotation_speed = ANGULAR_VELOCITY  # Adjust max rotation speed as needed
        self.rotate_future = self.rotate_client.send_goal_async(goal_msg)
        self.rotate_future.add_done_callback(self.rotate_done_callback)

    def rotate_done_callback(self, future):
        goal_handle = future.result()
        if not goal_handle.accepted:
            self.get_logger().info('Rotate to angle goal was rejected.')
        else:
            self.get_logger().info('Rotate to angle goal was accepted.')
    

    def obstacal_avoider(self):
        '''
        obstacal avoid algorithm with 7 IR sensors
        '''
        ################ Rotate Direction ################
        # clockwise, twist_msg.angular.z < 0
        # anti-clockwise, twist_msg.angular.z > 0
        # Obstacle detected, stop moving, turn to the direction where is no obstacle
        # If it is a corner, the robot will turn around
        ##################################################

        # Rotate to avoid obstacle
        # Rotate to the direction, that the signal strength is smaller
        if max(self.ir_vector[:4]) >= 150 >= max(self.ir_vector[-4:]):
            self.turn_clockwise()
        elif max(self.ir_vector[:4]) <= 150 <= max(self.ir_vector[-4:]):
            self.turn_anticlockwise()
            # Turn around to avoid corner
        elif (max(self.ir_vector[:4]) >= self.obstacle_threshold) and (max(self.ir_vector[-4:]) >= self.obstacle_threshold):
            self.rotate_robot(3.14)

    def hazard_callback(self, msg):
        '''
        Avoid the hazard for the robot
        '''
        self.get_logger().info(str(msg))

        for sensor in msg.detections:
            if sensor.header.frame_id == 'bump_left':
                self.rotate_robot(-1.57)
                self.get_logger().info('Hazard left')
            elif sensor.header.frame_id == 'bump_right':
                self.rotate_robot(1.57)
                self.get_logger().info('Hazard right')
            elif sensor.header.frame_id == 'bump_front_left':
                self.rotate_robot(0.78)
                self.get_logger().info('Hazard front left')
            elif sensor.header.frame_id == 'bump_front_right':
                self.rotate_robot(-0.78)
                self.get_logger().info('Hazard front right')
            elif sensor.header.frame_id == 'bump_front_center':
                self.rotate_robot(0.39)
                self.get_logger().info('Hazard front center')
        
    def ir_scan_callback(self, msg):
        '''
        generate the publish Twist msg
        '''

        # IR sensors position at the front [-0.5, -0.87, -1.22, -1.57, 1.22, 0.87, 0.5]

        # vector stores the seven IR sensors values 
        for sensor in msg.readings:
            self.ir_vector[ir_sensors[sensor.header.frame_id]] = sensor.value

        # self.get_logger().info(str(msg))
        self.get_logger().info(str(self.ir_vector))
        self.get_logger().info(str([self.obstacle_threshold < x for x in self.ir_vector]))

        obstacle_detected = any(self.obstacle_threshold < x for x in self.ir_vector)

        if obstacle_detected:
            self.obstacal_avoider()
        else: 
            self.move_forward()

        # Publish the twist message
        self.twist_msg.linear.x = v_vector["linear_x"]
        self.twist_msg.linear.y = v_vector["linear_y"]
        self.twist_msg.linear.z = v_vector["linear_z"]
        self.twist_msg.angular.x = v_vector["angular_x"]
        self.twist_msg.angular.y = v_vector["angular_y"]
        self.twist_msg.angular.z = v_vector["angular_z"]
        
        self.publisher.publish(self.twist_msg)


def main(args = []):
    rclpy.init(args=args)
    avoider = ObstacleAvoider()
    rclpy.spin(avoider)
    avoider.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()