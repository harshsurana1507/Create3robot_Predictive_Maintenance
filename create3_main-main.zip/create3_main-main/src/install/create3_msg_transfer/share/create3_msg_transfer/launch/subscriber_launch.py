from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():

    return LaunchDescription([
        Node(
            package='create3_msg_transfer',
            executable='battery_state_subscriber',
            name='battery_state_node',
            output='screen'
        )
    ])

if __name__ == '__main__':
    generate_launch_description()
