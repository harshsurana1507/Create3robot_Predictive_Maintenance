import rclpy
from rclpy.node import Node
from irobot_create_msgs.msg import Mouse
from rclpy.qos import QoSProfile, ReliabilityPolicy, LivelinessPolicy, DurabilityPolicy
from openpyxl import Workbook
from datetime import datetime

class MouseSubscriber(Node):
    def __init__(self):
        super().__init__('mouse_subscriber')

        topic_name = '/robot01/mouse'
        
        qos_profile = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            liveliness=LivelinessPolicy.AUTOMATIC,
            durability=DurabilityPolicy.VOLATILE,
            depth=1
        )

        self.subscription = self.create_subscription(
            Mouse,
            topic_name,
            self.mouse_callback,
            qos_profile
            )
        self.subscription  # prevent unused variable warning
        self.workbook = Workbook()
        self.worksheet = self.workbook.active
        self.worksheet.title = 'Mouse sensor data'
        self.worksheet.append(["Timestamp","integrated_x","integrated_y","frame_id","last_squal"])

        self.data = []
        self.timer = self.create_timer(2.0, self.process_buffered_messages)
        self.message_buffer = []

    

    def mouse_callback(self, msg):
        self.message_buffer.append(msg)


    def process_buffered_messages(self):
        if not self.message_buffer:
            return
        
        latest_msg = self.message_buffer[-1]

        #self.get_logger().info(str(msg))
        self.get_logger().info(f"Mouse sensor data: \n -integrated_x: {latest_msg.integrated_x} \n -integrated_y: {latest_msg.integrated_y} \n -frame id: {latest_msg.frame_id} \n -last_squal: {latest_msg.last_squal} \n\n")
        #current time and date
        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        self.data.append([current_time,latest_msg.integrated_x,latest_msg.integrated_y,latest_msg.frame_id,latest_msg.last_squal])
        self.message_buffer.clear()

    def save_to_excel(self):
        # Append collected data to the sheet
        for row in self.data:
            self.worksheet.append(row)

        # Save the workbook
        self.workbook.save('mouse sensor_data.xlsx')
        self.get_logger().info('Data saved to mouse sensor_data.xlsx')

    def destroy_node(self):
        
        # Save data to Excel before shutting down the node
        self.get_logger().info('Saving data to Excel...')
        self.save_to_excel()
        super().destroy_node()

def main(args=None):
    rclpy.init(args=args)
    mouse_subscriber = MouseSubscriber()
    try:
        rclpy.spin(mouse_subscriber)

    except KeyboardInterrupt:
         
         pass
    # Destroy the node explicitly
    # (optional - otherwise it will be done automatically
    # when the garbage collector destroys the node object)
    finally:
        if mouse_subscriber:
            mouse_subscriber.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()

if __name__ == '__main__':
    main()
