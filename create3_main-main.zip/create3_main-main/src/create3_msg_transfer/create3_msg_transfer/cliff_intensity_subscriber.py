import rclpy
from rclpy.node import Node
from irobot_create_msgs.msg import IrIntensityVector
from rclpy.qos import QoSProfile, ReliabilityPolicy, LivelinessPolicy, DurabilityPolicy
from openpyxl import Workbook
from datetime import datetime

class CliffIntensitySubscriber(Node):
    def __init__(self):
        super().__init__('cliff_intensity_subscriber')

        topic_name = '/robot01/cliff_intensity'
        
        qos_profile = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            liveliness=LivelinessPolicy.AUTOMATIC,
            durability=DurabilityPolicy.VOLATILE,
            depth=1
        )

        self.subscription = self.create_subscription(
            IrIntensityVector,
            topic_name,
            self.cliff_intensity_callback,
            qos_profile
            )
        self.subscription  # prevent unused variable warning
        self.workbook = Workbook()
        self.worksheet = self.workbook.active
        self.worksheet.title = 'Cliff Intensity'
        self.frame_ids = ["cliff_side_left", "cliff_front_left", "cliff_front_right", "cliff_side_right"]
        self.worksheet.append(["Timestamp"] + self.frame_ids)

        self.data = []
        self.timer = self.create_timer(2.0, self.process_buffered_messages)
        self.message_buffer = []
    

    def cliff_intensity_callback(self, msg):
        self.message_buffer.append(msg)

    def process_buffered_messages(self):
        if not self.message_buffer:
            return

        # Process the latest message from the buffer
        latest_msg = self.message_buffer[-1]

        # Current time and date
        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        # Create a dictionary to hold the readings for this timestamp
        row_data = {"Timestamp": current_time}
        for frame_id in self.frame_ids:
            row_data[frame_id] = None

        for intensity in latest_msg.readings:
            frame_id = intensity.header.frame_id
            ir_value = intensity.value
            row_data[frame_id] = ir_value
            self.get_logger().info(f"Cliff Intensity: \n - Frame ID: {frame_id} \n - the value is {ir_value} \n \n ----")

        # Append the row data to self.data
        self.data.append(row_data)
        self.message_buffer.clear()

    def save_to_excel(self):
        # Append collected data to the sheet
        for row in self.data:
            self.worksheet.append([row["Timestamp"]] + [row[frame_id] for frame_id in self.frame_ids])

        # Save the workbook
        self.workbook.save('cliff_intensity.xlsx')
        self.get_logger().info('Data saved to cliff_intensity.xlsx')

    def destroy_node(self):
        # Save data to Excel before shutting down the node
        self.get_logger().info('Saving data to Excel...')
        self.save_to_excel()
        super().destroy_node()
    

def main(args=None):
    rclpy.init(args=args)
    cliff_intensity_subscriber = CliffIntensitySubscriber()
    
    try:
        rclpy.spin(cliff_intensity_subscriber)
    except KeyboardInterrupt:
        pass
    finally:
        if cliff_intensity_subscriber:
            cliff_intensity_subscriber.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()

if __name__ == '__main__':
    main()
