import rclpy
from rclpy.node import Node
from irobot_create_msgs.msg import WheelVels
from rclpy.qos import QoSProfile, ReliabilityPolicy, LivelinessPolicy, DurabilityPolicy
from openpyxl import Workbook
from datetime import datetime

class WheelVelsSubscriber(Node):
    def __init__(self):
        super().__init__('wheel_vels_subscriber')

        topic_name = '/robot01/wheel_vels'
        
        qos_profile = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            liveliness=LivelinessPolicy.AUTOMATIC,
            durability=DurabilityPolicy.VOLATILE,
            depth=1
        )

        self.subscription = self.create_subscription(
            WheelVels,
            topic_name,
            self.wheel_vels_callback,
            qos_profile
            )
        self.subscription  # prevent unused variable warning
        self.workbook = Workbook()
        self.worksheet = self.workbook.active
        self.worksheet.title = 'wheel vels'
        self.worksheet.append(["Timestamp","velocity_left","velocity_right"])

        self.data = []
        self.timer = self.create_timer(2.0, self.process_buffered_messages)
        self.message_buffer = []


    def wheel_vels_callback(self, msg):
        self.message_buffer.append(msg)
    

    def process_buffered_messages(self):
        if not self.message_buffer:
            return

        # Process the latest message from the buffer
        latest_msg = self.message_buffer[-1]
        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.data.append([current_time, latest_msg.velocity_left, latest_msg.velocity_right])
        self.get_logger().info(f"Wheels velocity data processed at {current_time}: \n - wheel velocity left: {latest_msg.velocity_left} \n - wheel velocity right: {latest_msg.velocity_right} \n\n")

        # Clear the buffer
        self.message_buffer.clear()
    

    def save_to_excel(self):
        # Append collected data to the sheet
        for row in self.data:
            self.worksheet.append(row)

        # Save the workbook
        self.workbook.save('wheel vels.xlsx')
        self.get_logger().info('Data saved to wheel vels.xlsx')

    def destroy_node(self):
        
        # Save data to Excel before shutting down the node
        self.get_logger().info('Saving data to Excel...')
        self.save_to_excel()
        super().destroy_node()

def main(args=None):
    rclpy.init(args=args)
    wheel_vels_subscriber = WheelVelsSubscriber()
    try:
        rclpy.spin(wheel_vels_subscriber)

    except KeyboardInterrupt:
         
         pass
    # Destroy the node explicitly
    # (optional - otherwise it will be done automatically
    # when the garbage collector destroys the node object)
    finally:
        if wheel_vels_subscriber:
            wheel_vels_subscriber.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()

if __name__ == '__main__':
    main()
