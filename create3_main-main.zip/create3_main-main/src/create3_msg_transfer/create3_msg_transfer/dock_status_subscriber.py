import rclpy
from rclpy.node import Node
from irobot_create_msgs.msg import DockStatus
from rclpy.qos import QoSProfile, ReliabilityPolicy, LivelinessPolicy, DurabilityPolicy
from openpyxl import Workbook
from datetime import datetime

class DockStatusSubscriber(Node):
    def __init__(self):
        super().__init__('dock_status_subscriber')

        topic_name = '/robot01/dock_status'
        
        qos_profile = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            liveliness=LivelinessPolicy.AUTOMATIC,
            durability=DurabilityPolicy.VOLATILE,
            depth=1
        )

        self.subscription = self.create_subscription(
            DockStatus,
            topic_name,
            self.dock_status_callback,
            qos_profile
            )
        self.subscription  # prevent unused variable warning
        self.workbook = Workbook()
        self.worksheet = self.workbook.active
        self.worksheet.title = 'Dock Status'
        self.worksheet.append(["Timestamp", "Is it Docked", "Is Dock Visible"])
        self.data = []
        self.timer = self.create_timer(2.0, self.process_buffered_messages)
        self.message_buffer = []



    def dock_status_callback(self, msg):
        self.message_buffer.append(msg)

    
    def process_buffered_messages(self):
        if not self.message_buffer:
            return

        # Process the latest message from the buffer
        latest_msg = self.message_buffer[-1]
        #self.get_logger().info(str(msg))
        self.get_logger().info(f"Dock status: \n - is robot connected to charger: {latest_msg.is_docked} \n - is charging dock visible: {latest_msg.dock_visible} \n \n")
        #current time and date
        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        if latest_msg.is_docked == True:
            a = "Yes"
        
        if latest_msg.is_docked == False:
            a="No"
        
        if latest_msg.dock_visible == True:
            b="Yes"
        
        if latest_msg.dock_visible == False:
            b="No"
            

        
        
        self.data.append([current_time, a, b])
        self.message_buffer.clear()

        

    def save_to_excel(self):
        # Append collected data to the sheet
        for row in self.data:
            self.worksheet.append(row)

        # Save the workbook
        self.workbook.save("dock_status.xlsx")
        self.get_logger().info('Data saved to dock_status.xlsx')

    def destroy_node(self):
        
        # Save data to Excel before shutting down the node
        self.get_logger().info('Saving data to Excel...')
        self.save_to_excel()
        super().destroy_node()
    



def main(args=None):
    rclpy.init(args=args)
    dock_status_subscriber = DockStatusSubscriber()
    try:
        rclpy.spin(dock_status_subscriber)

    except KeyboardInterrupt:
         
         pass
    # Destroy the node explicitly
    # (optional - otherwise it will be done automatically
    # when the garbage collector destroys the node object)
    finally:
        if dock_status_subscriber:
            dock_status_subscriber.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()



if __name__ == '__main__':
    main()
