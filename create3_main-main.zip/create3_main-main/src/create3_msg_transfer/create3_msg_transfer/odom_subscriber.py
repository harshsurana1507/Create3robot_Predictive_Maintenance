import pandas as pd
import rclpy
from rclpy.node import Node
from nav_msgs.msg import Odometry
from rclpy.qos import QoSProfile, ReliabilityPolicy, LivelinessPolicy, DurabilityPolicy
from openpyxl import Workbook
from datetime import datetime




class OdomSubscriber(Node):
    def __init__(self):
        super().__init__('odom_subscriber')

        topic_name = '/robot01/odom'
        
        qos_profile = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            liveliness=LivelinessPolicy.AUTOMATIC,
            durability=DurabilityPolicy.VOLATILE,
            depth=1
        )

        self.subscription = self.create_subscription(
            Odometry,
            topic_name,
            self.odom_callback,
            qos_profile
            )
        self.subscription  # prevent unused variable warning
        self.workbook = Workbook()
        self.position_worksheet = self.workbook.active
        self.position_worksheet.title = 'Position data '
        self.position_worksheet.append(["Timestamp", "X", "Y","Z"])

        self.orientation_worksheet = self.workbook.create_sheet(title= 'Orientation data ')
        self.orientation_worksheet.append(["Timestamp", "X", "Y","Z","W"])

        self.lineartwist_worksheet = self.workbook.create_sheet(title= 'Linear twist data ')
        self.lineartwist_worksheet.append(["Timestamp", "X", "Y","Z"])


        self.angulartwist_worksheet = self.workbook.create_sheet(title= 'Angular twist data ')
        self.angulartwist_worksheet.append(["Timestamp", "X", "Y","Z"])

        self.position_data = []
        self.orientation_data = []
        self.lineartwist_data = []
        self.angulartwist_data = []

        self.timer = self.create_timer(2.0, self.process_buffered_messages)
        self.message_buffer = []




    def odom_callback(self, msg):
        self.message_buffer.append(msg)


    def process_buffered_messages(self):
        if not self.message_buffer:
            return
        
        latest_msg = self.message_buffer[-1]
        #self.get_logger().info(str(msg))
        pos_x = latest_msg.pose.pose.position.x
        pos_y = latest_msg.pose.pose.position.y
        pos_z = latest_msg.pose.pose.position.z

        orient_x = latest_msg.pose.pose.orientation.x
        orient_y = latest_msg.pose.pose.orientation.y
        orient_z = latest_msg.pose.pose.orientation.z
        orient_w = latest_msg.pose.pose.orientation.w

        litwist_x = latest_msg.twist.twist.linear.x
        litwist_y = latest_msg.twist.twist.linear.y
        litwist_z = latest_msg.twist.twist.linear.z

        angtwist_x = latest_msg.twist.twist.angular.x
        angtwist_y = latest_msg.twist.twist.angular.y
        angtwist_z = latest_msg.twist.twist.angular.z

        self.get_logger().info(f"Odometer data: \n - Position data --> x: {pos_x} y: {pos_y} z: {pos_z}\n - Orientation data-->  x:{orient_x} y: {orient_y} z: {orient_z} w:{orient_w} \n - Linear twist data -->x: {litwist_x} y: {litwist_y} z: {litwist_z} \n - Angular twist data -->x: {angtwist_x} y: {angtwist_y} z: {angtwist_z} \n \n")
        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.position_data.append([current_time,pos_x,pos_y,pos_z])
        self.orientation_data.append([current_time,orient_x,orient_y,orient_z,orient_w])
        self.lineartwist_data.append([current_time,litwist_x,litwist_y,litwist_z])
        self.angulartwist_data.append([current_time,angtwist_x,angtwist_y,angtwist_z])
        self.message_buffer.clear()

    def save_to_excel(self):
        # Append collected data to the sheet
        for a in self.position_data:
            self.position_worksheet.append(a)

        for b in self.orientation_data:
            self.orientation_worksheet.append(b)

        for c in self.lineartwist_data:
            self.lineartwist_worksheet.append(c)

        for d in self.angulartwist_data:
            self.angulartwist_worksheet.append(d)

        # Save the workbook
        self.workbook.save('odom_data.xlsx')
        self.get_logger().info('Data saved to odom_data.xlsx')

    def destroy_node(self):
        
        # Save data to Excel before shutting down the node
        self.get_logger().info('Saving data to Excel...')
        self.save_to_excel()
        super().destroy_node()
        



def main(args=None):
    rclpy.init(args=args)
    odom_subscriber = OdomSubscriber()
    
    try:    
         rclpy.spin(odom_subscriber)

    except KeyboardInterrupt:
         
         pass
    finally:
        if odom_subscriber:
            odom_subscriber.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()
     


if __name__ == '__main__':
    main()
