import rclpy
from rclpy.node import Node
from irobot_create_msgs.msg import WheelTicks
from rclpy.qos import QoSProfile, ReliabilityPolicy, LivelinessPolicy, DurabilityPolicy
from openpyxl import Workbook
from datetime import datetime

class WheelTicksSubscriber(Node):
    def __init__(self):
        super().__init__('wheel_ticks_subscriber')

        topic_name = '/robot01/wheel_ticks'
        
        qos_profile = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            liveliness=LivelinessPolicy.AUTOMATIC,
            durability=DurabilityPolicy.VOLATILE,
            depth=1
        )

        self.subscription = self.create_subscription(
            WheelTicks,
            topic_name,
            self.wheel_ticks_callback,
            qos_profile
            )
        self.subscription  # prevent unused variable warning
        self.workbook = Workbook()
        self.worksheet = self.workbook.active
        self.worksheet.title = 'wheel ticks'
        self.worksheet.append(["Timestamp","ticks_left","ticks_right"])
        
        self.timer = self.create_timer(2.0, self.process_buffered_messages)
        self.data = []
        self.message_buffer = []

    def wheel_ticks_callback(self, msg):
        self.message_buffer.append(msg)

    
    def process_buffered_messages(self):
        if not self.message_buffer:
            return
        latest_msg = self.message_buffer[-1]
        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        
        
        #self.get_logger().info(str(msg))
        self.get_logger().info(f"Wheel ticks data: \n -ticks_left: {latest_msg.ticks_left} \n -ticks_right: {latest_msg.ticks_right} \n\n")
        #current time and date
        
        self.data.append([current_time,latest_msg.ticks_left,latest_msg.ticks_right])
        self.message_buffer.clear()

    def save_to_excel(self):
        # Append collected data to the sheet
        for row in self.data:
            self.worksheet.append(row)

        # Save the workbook
        self.workbook.save('wheel ticks.xlsx')
        self.get_logger().info('Data saved to wheel ticks.xlsx')

    def destroy_node(self):
        
        # Save data to Excel before shutting down the node
        self.get_logger().info('Saving data to Excel...')
        self.save_to_excel()
        super().destroy_node()

def main(args=None):
    rclpy.init(args=args)
    wheel_ticks_subscriber = WheelTicksSubscriber()
    try:
        rclpy.spin(wheel_ticks_subscriber)

    except KeyboardInterrupt:
         
         pass
    # Destroy the node explicitly
    # (optional - otherwise it will be done automatically
    # when the garbage collector destroys the node object)
    finally:
        if wheel_ticks_subscriber:
            wheel_ticks_subscriber.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()

if __name__ == '__main__':
    main()
