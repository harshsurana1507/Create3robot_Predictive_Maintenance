# bridge_node.py (ROS 2 Humble on Machine C)
import rclpy
from rclpy.node import Node
from std_msgs.msg import String
import socket

class BridgeNode(Node):
    def __init__(self):
        super().__init__('bridge_node')
        self.subscription = self.create_subscription(
            String,
            '/robot01/battery_state',
            self.listener_callback,
            10)
        self.publisher_jazzy_socket = self.create_socket_publisher()

    def listener_callback(self, msg):
        self.get_logger().info(f'Received message from Humble: "{msg.data}"')
        self.publish_to_jazzy(msg.data)

    def create_socket_publisher(self):
        # Create a UDP socket
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        # Destination address (IP of Machine B and port)
        self.jazzy_address = ('100.82.81.50', 12345)
        return sock

    def publish_to_jazzy(self, message):
        self.publisher_jazzy_socket.sendto(message.encode(), self.jazzy_address)
        self.get_logger().info(f'Sent message to Jazzy: "{message}"')

def main(args=None):
    rclpy.init(args=args)
    node = BridgeNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
