import pandas as pd
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Imu
from rclpy.qos import QoSProfile, ReliabilityPolicy, LivelinessPolicy, DurabilityPolicy
from openpyxl import Workbook
from datetime import datetime




class ImuSubscriber(Node):
    def __init__(self):
        super().__init__('imu_subscriber')

        topic_name = '/robot01/imu'
        
        qos_profile = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            liveliness=LivelinessPolicy.AUTOMATIC,
            durability=DurabilityPolicy.VOLATILE,
            depth=1
        )

        self.subscription = self.create_subscription(
            Imu,
            topic_name,
            self.imu_callback,
            qos_profile
            )
        self.subscription  # prevent unused variable warning
        self.workbook = Workbook()
        self.orientation_worksheet = self.workbook.active
        self.orientation_worksheet.title = 'Orientation data '
        self.orientation_worksheet.append(["Timestamp", "X", "Y","Z","W"])

        self.velocity_worksheet = self.workbook.create_sheet(title= 'Angular Velocity data ')
        self.velocity_worksheet.append(["Timestamp", "X", "Y","Z"])

        self.acceleration_worksheet = self.workbook.create_sheet(title= 'Acceleeration data ')
        self.acceleration_worksheet.append(["Timestamp", "X", "Y","Z"])

        self.orientation_data = []
        self.velocity_data = []
        self.acceleration_data = []

        self.timer = self.create_timer(2.0, self.process_buffered_messages)
        self.message_buffer = []



    def imu_callback(self, msg):
        self.message_buffer.append(msg)

    
    def process_buffered_messages(self):
        if not self.message_buffer:
            return

        # Process the latest message from the buffer
        latest_msg = self.message_buffer[-1]

        #self.get_logger().info(str(msg))
        self.get_logger().info(f"IMU (Inertial Measurement Unit-new): \n - Orientation data --> x: {latest_msg.orientation.x} y: {latest_msg.orientation.y} z: {latest_msg.orientation.z} w:{latest_msg.orientation.w}\n - Angular Velocity data-->  x:{latest_msg.angular_velocity.x} y: {latest_msg.angular_velocity.y} z: {latest_msg.angular_velocity.z} \n - Linear acceleration data -->x: {latest_msg.linear_acceleration.x} y: {latest_msg.linear_acceleration.y} z: {latest_msg.linear_acceleration.z}")
        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.orientation_data.append([current_time,latest_msg.orientation.x,latest_msg.orientation.y,latest_msg.orientation.z,latest_msg.orientation.w])
        self.velocity_data.append([current_time,latest_msg.angular_velocity.x,latest_msg.angular_velocity.y,latest_msg.angular_velocity.z])
        self.acceleration_data.append([current_time,latest_msg.linear_acceleration.x,latest_msg.linear_acceleration.y,latest_msg.linear_acceleration.z])
        self.message_buffer.clear()


    
    def save_to_excel(self):
        # Append collected data to the sheet
        for a in self.orientation_data:
            self.orientation_worksheet.append(a)

        for b in self.velocity_data:
            self.velocity_worksheet.append(b)

        for c in self.acceleration_data:
            self.acceleration_worksheet.append(c)

        # Save the workbook
        self.workbook.save('imu.xlsx')
        self.get_logger().info('Data saved to imu_subscriber.xlsx')

    def destroy_node(self):
        
        # Save data to Excel before shutting down the node
        self.get_logger().info('Saving data to Excel...')
        self.save_to_excel()
        super().destroy_node()
        



def main(args=None):
    rclpy.init(args=args)
    imu_subscriber = ImuSubscriber()
    
    try:    
         rclpy.spin(imu_subscriber)

    except KeyboardInterrupt:
         
         pass
    finally:
        if imu_subscriber:
            imu_subscriber.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()
     


if __name__ == '__main__':
    main()
