def main():
    print('Hi from create3_control.')


if __name__ == '__main__':
    main()
