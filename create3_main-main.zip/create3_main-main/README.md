# iRobot Platform

This repository is opend to store the code or files related to the iRobot platform

![Ros2 structure](./docs/img/robotflott.drawio.png)

## Client Code

These code are running on Raspberry Pi5 boards.

It contains two packages, each of them contains nodes with different functions for the robot platform:

- Control: control the moving of the robot.
- Msg_transfer: subscribe the data, published by the sensors on iRobot, organized them, and publish them again to the server.
